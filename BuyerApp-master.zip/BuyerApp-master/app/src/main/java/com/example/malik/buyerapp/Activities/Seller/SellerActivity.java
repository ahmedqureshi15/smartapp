package com.example.malik.buyerapp.Activities.Seller;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.malik.buyerapp.Activities.AboutusActivity;
import com.example.malik.buyerapp.Activities.ProfileActivity;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.R;

import technolifestyle.com.imageslider.FlipperLayout;
import technolifestyle.com.imageslider.FlipperView;

public class SellerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    private FlipperLayout flipperLayout;
    private CardView addShops, addProducts, viewaddedShops, viewaddedProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        addShops = findViewById(R.id.addShopcardView);
        addProducts = findViewById(R.id.addProductcardview);
        viewaddedShops = findViewById(R.id.viewShopCardView);
        viewaddedProducts = findViewById(R.id.viewProductCardView);
        flipperLayout = findViewById(R.id.flipper);
        setLayout();

        addShops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent addShopIntent = new Intent(SellerActivity.this, AddShopsActivity.class);
                startActivity(addShopIntent);


            }
        });
        addProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addProductIntent = new Intent(SellerActivity.this, AddProductsActivity.class);
                startActivity(addProductIntent);
            }
        });

        viewaddedProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent viewProductIntent = new Intent(SellerActivity.this, ViewAddedProductActivity.class);
                startActivity(viewProductIntent);

            }
        });

        viewaddedShops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent viewShopIntent = new Intent(SellerActivity.this, ViewaddedShopsActivity.class);
                startActivity(viewShopIntent);

            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        View hView = navigationView.getHeaderView(0);
        TextView tvUserName = hView.findViewById(R.id.userName);

        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        tvUserName.setText(sharedPreferences.getString(Config.NAME_SHARED_PREF, "Not Available"));

        navigationView.setNavigationItemSelectedListener(this);
    }

    private void setLayout() {


        int images[] = {R.drawable.producta, R.drawable.productb, R.drawable.productc, R.drawable.productd};

        for (int i = 0; i < 4; i++) {

            FlipperView view = new FlipperView(getBaseContext());
            view.setImageDrawable(images[i]);
            flipperLayout.addFlipperView(view);

            view.setOnFlipperClickListener(new FlipperView.OnFlipperClickListener() {
                @Override
                public void onFlipperClick(FlipperView flipperView) {
                    Toast.makeText(SellerActivity.this, "" + (flipperLayout.getCurrentPagePosition() + 1), Toast.LENGTH_SHORT).show();
                }
            });

        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.seller, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_addShops) {

            Intent addShopIntent = new Intent(SellerActivity.this, AddShopsActivity.class);
            startActivity(addShopIntent);

        } else if (id == R.id.nav_addProducts) {

            Intent addProductIntent = new Intent(SellerActivity.this, AddProductsActivity.class);
            startActivity(addProductIntent);

        } else if (id == R.id.nav_profile) {

            Intent profileIntent = new Intent(SellerActivity.this, ProfileActivity.class);
            startActivity(profileIntent);


        } else if (id == R.id.nav_aboutUs) {

            Intent aboutusIntent = new Intent(SellerActivity.this, AboutusActivity.class);
            startActivity(aboutusIntent);

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_logout) {

            logout();

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    //Logout function
    private void logout(){
        //Creating an alert dialog to confirm logout
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure you want to logout?");
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        //Getting out sharedpreferences
                        SharedPreferences preferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                        //Getting editor
                        SharedPreferences.Editor editor = preferences.edit();

                        //Puting the value false for loggedin
                        editor.putBoolean(Config.LOGGEDIN_SHARED_SELLER, false);

                        //Putting blank value to email
                        editor.putString(Config.NO_SHARED_PREF, "");

                        //Saving the sharedpreferences
                        editor.commit();
                        editor.clear();

//                        Starting login activity
                        finish();
                    }
                });

        alertDialogBuilder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                    }
                });

        //Showing the alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }

}
