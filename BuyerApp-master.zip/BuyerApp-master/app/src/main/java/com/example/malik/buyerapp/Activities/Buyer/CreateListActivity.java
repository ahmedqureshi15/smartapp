package com.example.malik.buyerapp.Activities.Buyer;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.R;

import java.util.HashMap;

public class CreateListActivity extends AppCompatActivity {


    private TextView listName;
    private Button addShopBtn;
    String u_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);

        listName = findViewById(R.id.listName);
        addShopBtn = findViewById(R.id.addListBtn);

        addShopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createList();
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        u_id = sharedPreferences.getString(Config.ID_SHARED_PREF, "Not Available");

    }


    private void createList() {
        final String list_name = listName.getText().toString().trim();


        class UpdateList extends AsyncTask<Void, Void, String> {
            private ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(CreateListActivity.this, "Adding List...", "Please Wait...", false, false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if (s.equals("Successfully Register")) {
                    Toast.makeText(CreateListActivity.this, "List Added Successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(CreateListActivity.this, ShowListsActivity.class);
                    startActivity(intent);
                    finish();

                } else {
                    Toast.makeText(CreateListActivity.this, s, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.USER_ID, u_id);
                hashMap.put(Config.LIST_NAME, list_name);

                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.ADDLIST_URL, hashMap);
                return s;

            }
        }

        UpdateList ue = new UpdateList();
        ue.execute();
    }

}
