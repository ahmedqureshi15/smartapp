package com.example.malik.buyerapp.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.malik.buyerapp.Modalclasses.Product;
import com.example.malik.buyerapp.R;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.MyViewHolder> {


    private List<Product> productList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView productName, productPrice, productCategory;

        public MyViewHolder(View view) {
            super(view);
            productName =  view.findViewById(R.id.productName);
            productPrice = view.findViewById(R.id.productPrice);
            productCategory = view.findViewById(R.id.productCategory);
        }
    }

    public ProductAdapter(List<Product> productList) {
        this.productList = productList;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_list_layout, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Product product = productList.get(position);
        holder.productName.setText(product.getProductName());
        holder.productPrice.setText(product.getProductPrice());
        holder.productCategory.setText(product.getProductCategory());


    }

    @Override
    public int getItemCount() {
        return productList.size();
    }
}

