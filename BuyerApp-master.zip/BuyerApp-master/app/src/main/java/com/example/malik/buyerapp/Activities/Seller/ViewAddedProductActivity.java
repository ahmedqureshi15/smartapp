package com.example.malik.buyerapp.Activities.Seller;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.malik.buyerapp.Adapter.ProductAdapter;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.Modalclasses.Product;
import com.example.malik.buyerapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewAddedProductActivity extends AppCompatActivity {

    private ProgressDialog loading;

    String u_id;
    String data;
    private List<Product> productList = new ArrayList<>();
    private RecyclerView recyclerView;
    private ProductAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_added_product);

        recyclerView = findViewById(R.id.recycler_view);

        mAdapter = new ProductAdapter(productList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(),
                DividerItemDecoration.VERTICAL));



        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        u_id = sharedPreferences.getString(Config.ID_SHARED_PREF, "Not Available");

//        calling method
        GetProducts();

        }


    private void GetProducts() {
        final String user_id = u_id;
        loading = ProgressDialog.show(this, "Please wait...", "Fetching...", false, false);

        class UpdateProduct extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected void onPostExecute(String s) {
                loading.dismiss();
                super.onPostExecute(s);
                showproducts(s);

            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.USER_ID, user_id);
                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.GETPRODUCTSBYID_URL, hashMap);
                return s;

            }
        }

        UpdateProduct updateProduct = new UpdateProduct();
        updateProduct.execute();
    }

//    String status;

    private void showproducts(String response) {

        JSONObject obj = null;
        try {

//            Toast.makeText(this, response, Toast.LENGTH_SHORT).show();

            obj = new JSONObject(response);
            data = obj.getString("result");

            JSONArray newArray = new JSONArray(data);


//            JSONArray stu_id = new JSONArray();
            JSONArray product_name = new JSONArray();
            JSONArray product_price = new JSONArray();
            JSONArray product_cat = new JSONArray();

            for (int i = 0; i < newArray.length(); i++) {
//                String id = newArray.getJSONObject(i).getString("id");
                String p_name = newArray.getJSONObject(i).getString("p_name");
                String p_price = newArray.getJSONObject(i).getString("p_price");
                String p_category = newArray.getJSONObject(i).getString("p_category");

//                stu_id.put(id);
                product_name.put(p_name);
                product_price.put(p_price);
                product_cat.put(p_category);


                Product product= new Product(
                        newArray.getJSONObject(i).getString("p_name"),
                        newArray.getJSONObject(i).getString("p_price"),
                        newArray.getJSONObject(i).getString("p_category"));
                productList.add(product);


            }
            recyclerView.setAdapter(mAdapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }


}
