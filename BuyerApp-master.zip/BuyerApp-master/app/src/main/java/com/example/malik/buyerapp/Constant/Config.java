package com.example.malik.buyerapp.Constant;

/**
 * Created by Xhanii on 2/7/2017.
 */

public class Config {
    //Address of our scripts

    public static final String LOGIN_URL = "http://emanmuzzammil.com/fyp/login.php";
    public static final String REGISTER_URL = "http://emanmuzzammil.com/fyp/register.php";
    public static final String ADDSHOP_URL = "http://emanmuzzammil.com/fyp/addshop.php";
    public static final String DELETESHOPS_URL = "http://emanmuzzammil.com/fyp/deleteShops.php";
    public static final String ADDPRODUCT_URL = "http://emanmuzzammil.com/fyp/products.php";
    public static final String GETPRODUCTSBYID_URL = "http://emanmuzzammil.com/fyp/get_productsbyid.php";
    public static final String GETSHOPS_URL = "http://emanmuzzammil.com/fyp/get_shops.php";
    public static final String ADDLIST_URL = "http://emanmuzzammil.com/fyp/addlist.php";
    public static final String GETLISTBYID_URL = "http://emanmuzzammil.com/fyp/get_lists.php";
    public static final String GETALLPRODUCTS_URL = "http://emanmuzzammil.com/fyp/get_allproducts.php";
    public static final String ADDUSERPRODUCTLIST_URL = "http://emanmuzzammil.com/fyp/userProducts.php";
    public static final String GETUSERPRODUCTLIST_URL = "http://emanmuzzammil.com/fyp/getlistProducts.php";
    public static final String DELETEUSERPRODUCTLIST_URL = "http://emanmuzzammil.com/fyp/deletelProductfromist.php";
    public static final String DELETEUSERLIST_URL = "http://emanmuzzammil.com/fyp/deleteuserList.php";
    public static final String NOTIFICATION_URL = "http://emanmuzzammil.com/fyp/getNotification.php";
    public static final String UPDATE_PROFILE_URL = "http://emanmuzzammil.com/fyp/update_userprofile.php";


    //for login
    //Keys for phone and password as defined in our $_POST['key'] in login.php
    public static final String KEY_PHONE = "ph_no";
    public static final String KEY_PASSWORD = "password";

    //If server response is equal to this that means login is successful
    public static final String LOGIN_BUYER = "buyer";
    public static final String LOGIN_SELLER = "seller";

    //Keys for Sharedpreferences
    //This would be the name of our shared preferences
    public static final String SHARED_PREF_NAME = "myloginapp";
    public static final String SHARED_PREF_LOC = "getLocation";


    //We will use this to store the boolean in sharedpreference to track user is loggedin or not
    public static final String LOGGEDIN_SHARED_BUYER = "buyer_login";
    public static final String LOGGEDIN_SHARED_SELLER = "seller_login";
    public static final String LOC_SHARED_PREF = "locationRecieved";

    public static final String LOC_RESPONSE_SHARED_PREF = "response";


    //This would be used to store the id of current logged in user
    public static final String NO_SHARED_PREF = "ph_no";
//    public static final String NAME_SHARED_PREF = "user_name";

    //This would be used to store the data of current logged in user
    public static final String ID_SHARED_PREF = "u_id";
    public static final String EMAIL_SHARED_PREF = "user_email";
    public static final String NAME_SHARED_PREF = "user_name";
    public static final String TYPE_SHARED_PREF = "user_type";
    public static final String MOBILE_SHARED_PREF = "user_no";


    // for signup
    public static final String USER_ID = "u_id";
    public static final String SU_USER_NAME = "name";
    public static final String SU_USER_EMAIL = "email";
    public static final String SU_USER_MOBILE = "ph_no";
    public static final String SU_USER_PASS = "password";
    public static final String SU_USER_CATEGORY = "u_type";

    //    for adding shop
    public static final String SHOP_NAME = "shop_name";
    public static final String SHOP_LAT = "shop_lat";
    public static final String SHOP_LONGT = "shop_longt";


    //  for adding products
    public static final String PRODUCT_NAME = "p_name";
    public static final String PRODUCT_PRICE = "p_price";
    public static final String PRODUCT_CATEGORY = "p_category";

    //    for adding list
    public static final String LIST_ID = "l_id";

    public static final String LIST_NAME = "l_name";


    //    for deleting product list by users

    public static final String PRODUCT_ID = "id";
    //to post lat long
    public static final String USERLAT = "userLat";
    public static final String USERLONG = "userLong";

}
