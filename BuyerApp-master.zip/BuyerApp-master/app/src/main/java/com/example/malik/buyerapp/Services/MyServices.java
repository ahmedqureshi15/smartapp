package com.example.malik.buyerapp.Services;

import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;

import com.example.malik.buyerapp.Activities.Buyer.ShowListsActivity;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.R;

import static android.app.AlarmManager.ELAPSED_REALTIME;
import static android.os.SystemClock.elapsedRealtime;
import static com.example.malik.buyerapp.Constant.Config.LOC_SHARED_PREF;

/**
 * Created by xeeshan7860 on 11/1/2017.
 */

public class MyServices extends Service {
    public Handler mHandler;
    //    Login_form lg = new Login_form();
    Context context;
    boolean getLocation;
    String locationResponse;
    private final Runnable m_Runnable = new Runnable() {
        @TargetApi(Build.VERSION_CODES.O)
        @RequiresApi(api = Build.VERSION_CODES.O)
        public void run()

        {

//            Intent intent = new Intent(lg.getApplicationContext(), MyServices.class);
//            startActivity(intent);


            addNotification();
//            Toast.makeText(getApplicationContext(),"in runnable", Toast.LENGTH_SHORT).show();
            //TODO 24 Hours = 86,400,000 Milliseconds
            //TODO 3 Hours =  10,800,000 Milliseconds
            //TODO 5 Hours =  18,000,000 Milliseconds
            //TODO 1 Minute = 60,000 Milliseconds
            mHandler.postDelayed(m_Runnable, 5000);
        }

    };
    private boolean locationRecieved = false;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {

//        Intent intent = new Intent(dashboard.getApplicationContext(), MyServices.class);
//        startActivity(intent);

        super.onDestroy();
//        Toast.makeText(getApplicationContext(), "Stop Application Services", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    //TODO which command use in background services and When Application Closed from reselty task and App still run in background
    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

//    onTaskRemoved(intent);
// Toast.makeText(getApplicationContext(),"Started Service...Application runnning in background",Toast.LENGTH_SHORT).show();
        this.mHandler = new Handler();

        m_Runnable.run();
        // return START_NOT_STICKY;
        return START_STICKY;
    }

    //TODO When Task Removed app run in Background
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());
//        super.onTaskRemoved(rootIntent); restartServiceIntent.setPackage(getPackageName());
//        PendingIntent restartPendingIntent =PendingIntent.getService(getApplicationContext(), 1,restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
//        AlarmManager myAlarmService = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
//        myAlarmService.set(AlarmManager.ELAPSED_REALTIME,SystemClock.elapsedRealtime() + 1000,restartPendingIntent);

        PendingIntent restartServicePendingIntent = PendingIntent.getService(
                getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmService = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmService.set(ELAPSED_REALTIME, elapsedRealtime() + 1000,
                restartServicePendingIntent);


    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void addNotification() {

//        In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_LOC, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        getLocation = sharedPreferences.getBoolean(LOC_SHARED_PREF, false);

        //If it will get true
        if (getLocation) {

//            SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
            locationResponse = sharedPreferences.getString(Config.LOC_RESPONSE_SHARED_PREF, "Not Available");
            //Three Phases of BIGNOTIFICATION
            //Style
            NotificationCompat.BigTextStyle style = new android.support.v4.app.NotificationCompat.BigTextStyle();
            style.setBigContentTitle("FYP App Notification");
//        style.bigText("This is a notification to remind you that your" +
//                " document near to expire.\n Touch to check document.\n Thankyou" );

            style.setBigContentTitle(locationResponse);

            int notifyID = 1;
            String CHANNEL_ID = "my_channel_01";// The id of the channel.
            CharSequence name = getString(R.string.app_name);// The user-visible name of the channel.
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);

            //Normal
            //Buid the content of notfication
            NotificationCompat.Builder notificationCompat = new NotificationCompat.Builder(MyServices.this);
            notificationCompat.setContentTitle("Notification");
//            notificationCompat.setContentText("Touch to check List");
            notificationCompat.setContentText(locationResponse);
            notificationCompat.setSmallIcon(R.drawable.loggo);
            notificationCompat.setTicker("FYP App Notification");
//            notificationCompat.setStyle(new NotificationCompat.BigTextStyle().bigText(locationResponse));
            notificationCompat.setChannelId(CHANNEL_ID);
            notificationCompat.setAutoCancel(true);
            notificationCompat.setStyle(style);


            //normalNotification Method
            Intent intent = new Intent(this, ShowListsActivity.class);
            TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(this);
            taskStackBuilder.addParentStack(ShowListsActivity.class);
            taskStackBuilder.addNextIntent(intent);

//            ------- location sharedpref clear
//Getting out sharedpreferences
            SharedPreferences preferences = getSharedPreferences(Config.SHARED_PREF_LOC, Context.MODE_PRIVATE);
            //Getting editor
            SharedPreferences.Editor editor = preferences.edit();

            //Puting the value false for loggedin
            editor.putBoolean(Config.LOC_SHARED_PREF, false);

            //Putting blank value to email
            editor.putString(Config.LOC_RESPONSE_SHARED_PREF, "");

            //Saving the sharedpreferences
            editor.commit();
            editor.clear();

            //            -------- end sahredpref
            PendingIntent pi_main = taskStackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
            notificationCompat.setContentIntent(pi_main);

            //Passing the Notification Manager
            //Notification through notification Manager
            Notification notification = notificationCompat.build();
            NotificationManager manager = (NotificationManager) this.getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(mChannel);
            manager.notify(notifyID, notification);


        }
    }
}



