package com.example.malik.buyerapp.Activities.Seller;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.malik.buyerapp.Activities.LoginActivity;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.R;

import java.util.HashMap;

public class AddProductsActivity extends AppCompatActivity implements View.OnClickListener  {

    private EditText productName, productCategoray, productPrice;
    private Button addProduct;
    String u_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_products);


        productName = findViewById(R.id.productName);
        productCategoray = findViewById(R.id.productCategory);
        productPrice = findViewById(R.id.productPrice);
        addProduct = findViewById(R.id.addProduct);

        addProduct.setOnClickListener(this);

        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
         u_id = sharedPreferences.getString(Config.ID_SHARED_PREF, "Not Available");
//        String u_no = sharedPreferences.getString(Config.MOBILE_SHARED_PREF, "Not Available");


//        userid.equals(u_id);
//        userno.setText(u_no.toString());


    }


    // creating method to create shop

    private void CreateShop() {
//        final String user_id = u_id.trim();
        final String p_name = productName.getText().toString().trim();
        final String p_price = productPrice.getText().toString().trim();
        final String p_category = productCategoray.getText().toString().trim();


        class UpdateEmployee extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(AddProductsActivity.this, "Adding Products...", "Please Wait...", false, false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if (s.equals("Successfully Register")) {
                    Toast.makeText(AddProductsActivity.this, "Products Added Successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddProductsActivity.this, LoginActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(AddProductsActivity.this, s, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.USER_ID, u_id);
                hashMap.put(Config.PRODUCT_NAME, p_name);
                hashMap.put(Config.PRODUCT_PRICE, p_price);
                hashMap.put(Config.PRODUCT_CATEGORY, p_category);

                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.ADDPRODUCT_URL, hashMap);
                return s;

            }
        }

        UpdateEmployee ue = new UpdateEmployee();
        ue.execute();
    }


    @Override
    public void onClick(View view) {

        if (view == addProduct) {

            CreateShop();

        }

    }

}
