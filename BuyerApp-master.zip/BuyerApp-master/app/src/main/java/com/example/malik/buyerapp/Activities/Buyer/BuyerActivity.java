package com.example.malik.buyerapp.Activities.Buyer;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.malik.buyerapp.Activities.AboutusActivity;
import com.example.malik.buyerapp.Activities.ProfileActivity;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.R;
import com.example.malik.buyerapp.Services.MyServices;

import java.util.HashMap;
import java.util.Map;

import technolifestyle.com.imageslider.FlipperLayout;
import technolifestyle.com.imageslider.FlipperView;

public class BuyerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;
    Handler mHandler;
    private FlipperLayout flipperLayout;
    String lattitude, longitude;
    //runable function here
    private final Runnable m_Runnable = new Runnable() {
        @RequiresApi(api = Build.VERSION_CODES.O)
        public void run()

        {
            // Toast.makeText(Dashboard.this,"Tracking", Toast.LENGTH_SHORT).show();
            TrackLoc();
//            addNotification();
            BuyerActivity.this.mHandler.postDelayed(m_Runnable, 90000);
        }

    };
    private CardView allProducts, addedProduct, showLists;

    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        allProducts = findViewById(R.id.buyerAllProducs);
        addedProduct = findViewById(R.id.buyerViewAddedProducts);
        showLists = findViewById(R.id.lists);
        flipperLayout = findViewById(R.id.flipper);
        setLayout();

        allProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent createListIntent = new Intent(BuyerActivity.this, BuyerProductActivity.class);
                startActivity(createListIntent);

            }
        });

        addedProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Intent addedProductIntent = new Intent(BuyerActivity.this, ShowListsActivity.class);
//                startActivity(addedProductIntent);

            }
        });

        showLists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent chooseIntent = new Intent(BuyerActivity.this, ShowListsActivity.class);
                startActivity(chooseIntent);
            }
        });


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View hView = navigationView.getHeaderView(0);
        TextView tvUserName = hView.findViewById(R.id.userName);

        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        tvUserName.setText(sharedPreferences.getString(Config.NAME_SHARED_PREF, "Not Available"));

        navigationView.setNavigationItemSelectedListener(this);

        ViewLocation();

        Intent service = new Intent(this, MyServices.class);

        startService(service);

        this.mHandler = new Handler();
        m_Runnable.run();

    }

    private void ViewLocation() {


        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            getLocation();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void getLocation() {

        if (ActivityCompat.checkSelfPermission(BuyerActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (BuyerActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(BuyerActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        } else {
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            Location location1 = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            Location location2 = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            if (location != null) {
                double latti = location.getLatitude();
                double longi = location.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

//                et_lat.setText(lattitude);
//                et_longt.setText(longitude);

//                Toast.makeText(AddShopsActivity.this,"Your current location is"+ "\n" + "Lattitude = " + lattitude
//                        + "\n" + "Longitude = " + longitude,Toast.LENGTH_SHORT).show();


            } else if (location1 != null) {
                double latti = location1.getLatitude();
                double longi = location1.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

//                et_lat.setText(lattitude);
//                et_longt.setText(longitude);


                Toast.makeText(BuyerActivity.this, "Your current location is" + "\n" + "Lattitude = " + lattitude
                        + "\n" + "Longitude = " + longitude, Toast.LENGTH_SHORT).show();

            } else if (location2 != null) {
                double latti = location2.getLatitude();
                double longi = location2.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

//                et_lat.setText(lattitude);
//                et_longt.setText(longitude);

//                Toast.makeText(AddShopsActivity.this,"Your current location is"+ "\n" + "Lattitude = " + lattitude
//                        + "\n" + "Longitude = " + longitude,Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this, "Unble to Trace your location", Toast.LENGTH_SHORT).show();

            }
        }

    }

    private void buildAlertMessageNoGps() {

        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Please Turn ON your GPS Connection")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final android.app.AlertDialog alert = builder.create();
        alert.show();

    }


    public void TrackLoc() {


        //Creating a string request
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.NOTIFICATION_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

//                        Toast.makeText(BuyerActivity.this, response, Toast.LENGTH_SHORT).show();
                        //If we are getting success from server
                        if (response != null) {
//                            //Creating a shared preference
                            SharedPreferences sharedPreferences = BuyerActivity.this.getSharedPreferences(Config.SHARED_PREF_LOC, Context.MODE_PRIVATE);
//
//                            //Creating editor to store values to shared preferences
                            SharedPreferences.Editor editor = sharedPreferences.edit();
//
//                            //Adding values to editor
                            editor.putBoolean(Config.LOC_SHARED_PREF, true);
                            editor.putString(Config.LOC_RESPONSE_SHARED_PREF, response);
//
//                            //Saving values to editor
                            editor.commit();

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //You can handle error here if you want
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                params.put(Config.USERLAT, lattitude);
                params.put(Config.USERLONG, longitude);

                //returning parameter
                return params;
            }
        };

        //Adding the string request to the queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void setLayout() {


        int images[] = {R.drawable.producta, R.drawable.productb, R.drawable.productc, R.drawable.productd};

        for (int i = 0; i < 4; i++) {

            FlipperView view = new FlipperView(getBaseContext());
            view.setImageDrawable(images[i]);
            flipperLayout.addFlipperView(view);

            view.setOnFlipperClickListener(new FlipperView.OnFlipperClickListener() {
                @Override
                public void onFlipperClick(FlipperView flipperView) {
                    Toast.makeText(BuyerActivity.this, "" + (flipperLayout.getCurrentPagePosition() + 1), Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.buyer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_list) {

            Intent createListIntent = new Intent(BuyerActivity.this, ShowListsActivity.class);
            startActivity(createListIntent);


        } else if (id == R.id.nav_allProduct) {

            Intent addedProductIntent = new Intent(BuyerActivity.this, BuyerProductActivity.class);
            startActivity(addedProductIntent);

        } else if (id == R.id.nav_task) {

            Intent chooseIntent = new Intent(BuyerActivity.this, BuyerProductActivity.class);
            startActivity(chooseIntent);


        } else if (id == R.id.nav_profile) {

            Intent profileIntent = new Intent(BuyerActivity.this, ProfileActivity.class);
            startActivity(profileIntent);

        } else if (id == R.id.nav_about) {

            Intent aboutusIntent = new Intent(BuyerActivity.this, AboutusActivity.class);
            startActivity(aboutusIntent);

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_buyerLogout) {

            logout();

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    //Logout function
    private void logout() {
        //Creating an alert dialog to confirm logout
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure you want to logout?");
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        //Getting out sharedpreferences
                        SharedPreferences preferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
                        //Getting editor
                        SharedPreferences.Editor editor = preferences.edit();

                        //Puting the value false for loggedin
                        editor.putBoolean(Config.LOGGEDIN_SHARED_BUYER, false);

                        //Putting blank value to email
                        editor.putString(Config.NO_SHARED_PREF, "");

                        //Saving the sharedpreferences
                        editor.commit();
                        editor.clear();

//                        Starting login activity
                        finish();
                    }
                });

        alertDialogBuilder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                    }
                });

        //Showing the alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }


}
