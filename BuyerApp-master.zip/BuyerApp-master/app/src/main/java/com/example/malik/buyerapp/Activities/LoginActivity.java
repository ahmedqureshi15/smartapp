package com.example.malik.buyerapp.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.malik.buyerapp.Activities.Buyer.BuyerActivity;
import com.example.malik.buyerapp.Activities.Seller.SellerActivity;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.R;
import com.example.malik.buyerapp.VolleySingleton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private boolean buyer_login, seller_login = false;
    private EditText phone, password;
    private Button login;
    private RequestQueue requestQueue;
    private TextView registerTextview, forgetPassword;
    private Spinner spinner;
    String userType[] = {"Select user type", "Buyer", "Seller"};
    ArrayAdapter<String> arrayAdapter;
    String login_status, u_name, u_no, u_email, user_type, u_id;
    ProgressDialog loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

//        spinner = findViewById(R.id.spinnerBar);
        phone = findViewById(R.id.loginPhone);
        password = findViewById(R.id.loginPass);
        login = findViewById(R.id.loginBtn);
        forgetPassword = findViewById(R.id.forgetPassword);
        registerTextview = findViewById(R.id.signupText);

        login.setOnClickListener(this);
        forgetPassword.setOnClickListener(this);
        registerTextview.setOnClickListener(this);


//        arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,userType);
//        spinner.setAdapter(arrayAdapter);


    }

//    store login cred..

    @Override
    protected void onResume() {
        super.onResume();
        //In onresume fetching value from sharedpreference
        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);

        //Fetching the boolean value form sharedpreferences
        buyer_login = sharedPreferences.getBoolean(Config.LOGGEDIN_SHARED_BUYER, false);
        seller_login = sharedPreferences.getBoolean(Config.LOGGEDIN_SHARED_SELLER, false);

        //If we will get true
        if (buyer_login) {

            Intent intent = new Intent(LoginActivity.this, BuyerActivity.class);
            startActivity(intent);


        } else if (seller_login) {

            Intent intent = new Intent(LoginActivity.this, SellerActivity.class);
            startActivity(intent);

        }


    }


    // Login method
    @Override
    public void onClick(View view) {
        if (view == login) {
//            Intent forgetIntent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
//                startActivity(forgetIntent);
            login();

        }
        if (view == forgetPassword) {
            Intent forgetIntent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
            startActivity(forgetIntent);

        }
        if (view == registerTextview) {
            Intent forgetIntent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(forgetIntent);

        }


    }


    private void login() {
        //Getting values from edit texts
        final String user_no = phone.getText().toString().trim();
        final String user_pass = password.getText().toString().trim();


        if (TextUtils.isEmpty(user_no)) {
            phone.setError("Please enter your phone no");
            phone.requestFocus();
            return;
        }


        if (TextUtils.isEmpty(user_pass)) {
            password.setError("Enter a password");
            password.requestFocus();
            return;
        }

        loading = ProgressDialog.show(LoginActivity.this, "Redirecting...", "Please Wait...", false, false);

        //Creating a string request
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.LOGIN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        String json = response;
                        loading.dismiss();
//                        Toast.makeText(LoginActivity.this, response, Toast.LENGTH_SHORT).show();
                        try {
                            // get JSONObject from JSON file
                            JSONObject obj = new JSONObject(json);

                            login_status = obj.getString("result").substring(1);
                            JSONObject newOBJ = new JSONObject(login_status);
                            u_id = newOBJ.getString("u_id");
                            u_name = newOBJ.getString("name");
                            user_type = newOBJ.getString("u_type");
                            u_email = newOBJ.getString("email");
                            u_no = newOBJ.getString("ph_no");

                            if (user_type.equals("buyer")) {

                                //Creating a shared preference
                                SharedPreferences sharedPreferences = LoginActivity.this.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                                //Creating editor to store values to shared preferences
                                SharedPreferences.Editor editor = sharedPreferences.edit();

                                //Adding values to editor
                                editor.putBoolean(Config.LOGGEDIN_SHARED_BUYER, true);
                                editor.putString(Config.ID_SHARED_PREF, u_id);
                                editor.putString(Config.EMAIL_SHARED_PREF, u_email);
                                editor.putString(Config.NAME_SHARED_PREF, u_name);
                                editor.putString(Config.TYPE_SHARED_PREF, user_type);
                                editor.putString(Config.MOBILE_SHARED_PREF, u_no);

                                //Saving values to editor
                                editor.commit();
                                phone.setText("");
                                password.setText("");

                                Intent intent = new Intent(LoginActivity.this, BuyerActivity.class);
                                startActivity(intent);
                                finish();


                            }
                            if (user_type.equals("seller")) {

                                SharedPreferences sharedPreferences = LoginActivity.this.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                                //Creating editor to store values to shared preferences
                                SharedPreferences.Editor editor = sharedPreferences.edit();

                                //Adding values to editor
                                editor.putBoolean(Config.LOGGEDIN_SHARED_SELLER, true);
                                editor.putString(Config.ID_SHARED_PREF, u_id);
                                editor.putString(Config.EMAIL_SHARED_PREF, u_email);
                                editor.putString(Config.NAME_SHARED_PREF, u_name);
                                editor.putString(Config.TYPE_SHARED_PREF, user_type);
                                editor.putString(Config.MOBILE_SHARED_PREF, u_no);

                                //Saving values to editor
                                editor.commit();
                                phone.setText("");
                                password.setText("");


                                Intent intent = new Intent(LoginActivity.this, SellerActivity.class);
                                startActivity(intent);
                                finish();

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(LoginActivity.this, "Invalid Phone Number Or Password", Toast.LENGTH_SHORT).show();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //You can handle error here if you want
                        loading.dismiss();
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                            Toast.makeText(LoginActivity.this, "Your device is not connected to internet.", Toast.LENGTH_SHORT).show();

                        } else if (error instanceof AuthFailureError) {
                            Toast.makeText(LoginActivity.this, "These credentials do not match our records.", Toast.LENGTH_SHORT).show();

                            //TODO
                        } else if (error instanceof ServerError) {

                            //TODO
                            Toast.makeText(LoginActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();

                        } else if (error instanceof NetworkError) {
                            //TODO
                            Toast.makeText(LoginActivity.this, "Network Error ", Toast.LENGTH_SHORT).show();

                        } else if (error instanceof ParseError) {
                            //TODO
                            Toast.makeText(LoginActivity.this, "Parse Error: ", Toast.LENGTH_SHORT).show();

                        }
//                        Toast.makeText(RegistrationActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show();


                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                params.put(Config.KEY_PHONE, user_no);
                params.put(Config.KEY_PASSWORD, user_pass);

                //returning parameter
                return params;
            }
        };

        //Adding the string request to the queue
        requestQueue = VolleySingleton.getmInstance(this).getRequestQueue();
        requestQueue.add(stringRequest);
    }

}