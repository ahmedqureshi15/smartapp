package com.example.malik.buyerapp.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.R;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView loginText;
    private Spinner spinner;
    String userType[] = {"Please Select user type", "buyer", "seller"};
    ArrayAdapter<String> arrayAdapter;

    private EditText name, email, phone, password, retype;
private Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name = findViewById(R.id.registerName);
        email = findViewById(R.id.registerEmail);
        phone = findViewById(R.id.registerPhone);
        password = findViewById(R.id.registerPassword);
        retype = findViewById(R.id.retypePassword);
        register = findViewById(R.id.registerButton);
        register.setOnClickListener(this);
        spinner = findViewById(R.id.resgisterSpinner);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, userType);
        spinner.setAdapter(arrayAdapter);


        loginText = findViewById(R.id.textLogin);
//        loginText.setOnClickListener(this);


        loginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(loginIntent);            }
        });

    }

// register user method
    private void RegisterUser() {
        final String user_name = name.getText().toString().trim();
        final String user_id = email.getText().toString().trim();
        final String user_mobile = phone.getText().toString().trim();
        final String user_pass = password.getText().toString().trim();
        final String user_type = spinner.getSelectedItem().toString().trim();
//        final String user_country = country.getText().toString().trim();




        class UpdateEmployee extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(RegisterActivity.this, "User Creating...", "Please Wait...", false, false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if(s.equals("Successfully Register")){
                    Toast.makeText(RegisterActivity.this, "Registered Successfully", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(RegisterActivity.this, s, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.SU_USER_NAME, user_name);
                hashMap.put(Config.SU_USER_EMAIL, user_id);
                hashMap.put(Config.SU_USER_MOBILE, user_mobile);
                hashMap.put(Config.SU_USER_PASS, user_pass);
                hashMap.put(Config.SU_USER_CATEGORY, user_type);

                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.REGISTER_URL, hashMap);
                return s;

            }
        }

        UpdateEmployee ue = new UpdateEmployee();
        ue.execute();
    }



    @Override
    public void onClick(View view) {



        final String user_id = email.getText().toString().trim();
        /**
         //         * Validation
         //
         //         */
        boolean invalid = false;
        if (name.getText().length()==0) {
            name.setError("Please Enter Your Name");
        }
        else if (email.getText().length()==0) {
            email.setError("Please Enter Your Emai Address");
        }
        else if (!user_id.matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")) {
            email.requestFocus();
            email.setError("Invalid Email Address");
        }
        else if (phone.getText().length()==0) {
            phone.setError("Please Enter  Phone Number");
        }
        else if (phone.getText().length()<11 && phone.getText().length()>11) {
            phone.setError("Please Enter Correct Phone Number");
        }

        else if (password.getText().length()==0) {
            password.setError("Please Enter Password");
        }
        else if (retype.getText().length()==0) {
            retype.setError("Retype Password");
        }
        else if (spinner.getSelectedItem().toString().equals("Please Select user type")) {

            Toast.makeText(getApplicationContext(), "Please select any user type",Toast.LENGTH_LONG).show();
//            spinner.getSelectedItem()
//            spinner.setError("Select any user type");
//            password.requestFocus();
//            return;
        }
        else if (view == register) {
            if (password.getText().toString().equals(retype.getText().toString())) {
                RegisterUser();

            }
            else{
                //Toast is the pop up message
                Toast.makeText(getApplicationContext(), "Password does not match!",
                        Toast.LENGTH_LONG).show();
            }


        }

    }
}
