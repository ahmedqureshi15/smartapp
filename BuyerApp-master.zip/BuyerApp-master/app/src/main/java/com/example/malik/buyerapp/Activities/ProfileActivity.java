package com.example.malik.buyerapp.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.malik.buyerapp.Activities.Buyer.BuyerActivity;
import com.example.malik.buyerapp.Activities.Seller.SellerActivity;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.R;

import java.util.HashMap;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etName, etEmail, etPhone, etPass;
    private Button btnSubmit;
    private String userType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        etName = findViewById(R.id.editName);
        etEmail = findViewById(R.id.editEmail);
        etPhone = findViewById(R.id.editPhone);
        etPass = findViewById(R.id.editPassword);

        btnSubmit = findViewById(R.id.profileUpdateButton);
        btnSubmit.setOnClickListener(this);

        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
//        userId = sharedPreferences.getString(Config.ID_SHARED_PREF, "Not Available");
        etEmail.setText(sharedPreferences.getString(Config.EMAIL_SHARED_PREF, "Not Available"));
        etName.setText(sharedPreferences.getString(Config.NAME_SHARED_PREF, "Not Available"));
        etPhone.setText(sharedPreferences.getString(Config.MOBILE_SHARED_PREF, "Not Available"));
        userType = sharedPreferences.getString(Config.TYPE_SHARED_PREF, "Not Available");


    }


    // update user method
    private void updateUser() {
        final String user_name = etName.getText().toString().trim();
        final String user_email = etEmail.getText().toString().trim();
        final String user_mobile = etPhone.getText().toString().trim();
        final String user_pass = etPass.getText().toString().trim();
//        final String user_type = spinner.getSelectedItem().toString().trim();
//        final String user_country = country.getText().toString().trim();


        class UpdateEmployee extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(ProfileActivity.this, "User Creating...", "Please Wait...", false, false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if (s.equals("success")) {
                    Toast.makeText(ProfileActivity.this, "Update Successfully", Toast.LENGTH_LONG).show();

                    if (userType.equals("buyer")) {

                        //Creating a shared preference
                        SharedPreferences sharedPreferences = ProfileActivity.this.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                        //Creating editor to store values to shared preferences
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        //Adding values to editor
                        editor.putBoolean(Config.LOGGEDIN_SHARED_BUYER, true);
//                        editor.putString(Config.ID_SHARED_PREF, u_id);
                        editor.putString(Config.EMAIL_SHARED_PREF, user_email);
                        editor.putString(Config.NAME_SHARED_PREF, user_name);
                        editor.putString(Config.MOBILE_SHARED_PREF, user_mobile);

                        //Saving values to editor
                        editor.commit();
//                        phone.setText("");
//                        password.setText("");

                        finish();
                        Intent intent = new Intent(ProfileActivity.this, BuyerActivity.class);

                        startActivity(intent);

                    }
                    if (userType.equals("seller")) {

                        SharedPreferences sharedPreferences = ProfileActivity.this.getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);

                        //Creating editor to store values to shared preferences
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        //Adding values to editor
                        editor.putBoolean(Config.LOGGEDIN_SHARED_SELLER, true);
                        editor.putString(Config.EMAIL_SHARED_PREF, user_email);
                        editor.putString(Config.NAME_SHARED_PREF, user_name);
                        editor.putString(Config.MOBILE_SHARED_PREF, user_mobile);

                        //Saving values to editor
                        editor.commit();
//                        phone.setText("");
//                        password.setText("");


                        finish();
                        Intent intent = new Intent(ProfileActivity.this, SellerActivity.class);

                        startActivity(intent);

                    }
                } else {
                    Toast.makeText(ProfileActivity.this, s, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.SU_USER_NAME, user_name);
                hashMap.put(Config.SU_USER_EMAIL, user_email);
                hashMap.put(Config.SU_USER_MOBILE, user_mobile);
                hashMap.put(Config.SU_USER_PASS, user_pass);
//                hashMap.put(Config.SU_USER_CATEGORY, user_type);

                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.UPDATE_PROFILE_URL, hashMap);
                return s;

            }
        }

        UpdateEmployee ue = new UpdateEmployee();
        ue.execute();
    }


    @Override
    public void onClick(View view) {
        if (view == btnSubmit) {

            updateUser();
        }


    }
}
