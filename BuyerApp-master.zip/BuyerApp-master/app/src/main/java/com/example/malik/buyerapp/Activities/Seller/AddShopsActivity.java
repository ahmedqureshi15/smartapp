package com.example.malik.buyerapp.Activities.Seller;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.R;

import java.util.HashMap;

public class AddShopsActivity extends AppCompatActivity implements View.OnClickListener{

    private Button addShops;
    private static final String TAG = "addshopactivity";
    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;
    String lattitude,longitude;
    private EditText et_lat,et_longt,et_shopname;
    String u_id;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_shops);

        et_lat = findViewById(R.id.shopLat);
        et_longt = findViewById(R.id.shopLongt);
        et_shopname = findViewById(R.id.shopName);

        addShops = findViewById(R.id.addshopBtn);
        addShops.setOnClickListener(this);

        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        u_id = sharedPreferences.getString(Config.ID_SHARED_PREF, "Not Available");


//location method calling on create
        ViewLocation();


    }

    private void ViewLocation() {


        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            getLocation();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void getLocation() {

        if (ActivityCompat.checkSelfPermission(AddShopsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                (AddShopsActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(AddShopsActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        } else {
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            Location location1 = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            Location location2 = locationManager.getLastKnownLocation(LocationManager. PASSIVE_PROVIDER);

            if (location != null) {
                double latti = location.getLatitude();
                double longi = location.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                et_lat.setText(lattitude);
                et_longt.setText(longitude);

//                Toast.makeText(AddShopsActivity.this,"Your current location is"+ "\n" + "Lattitude = " + lattitude
//                        + "\n" + "Longitude = " + longitude,Toast.LENGTH_SHORT).show();


            } else  if (location1 != null) {
                double latti = location1.getLatitude();
                double longi = location1.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                et_lat.setText(lattitude);
                et_longt.setText(longitude);


//                Toast.makeText(AddShopsActivity.this,"Your current location is"+ "\n" + "Lattitude = " + lattitude
//                        + "\n" + "Longitude = " + longitude,Toast.LENGTH_SHORT).show();

            } else  if (location2 != null) {
                double latti = location2.getLatitude();
                double longi = location2.getLongitude();
                lattitude = String.valueOf(latti);
                longitude = String.valueOf(longi);

                et_lat.setText(lattitude);
                et_longt.setText(longitude);

//                Toast.makeText(AddShopsActivity.this,"Your current location is"+ "\n" + "Lattitude = " + lattitude
//                        + "\n" + "Longitude = " + longitude,Toast.LENGTH_SHORT).show();

            }else{

                Toast.makeText(this,"Unble to Trace your location",Toast.LENGTH_SHORT).show();

            }
        }

    }

    private void buildAlertMessageNoGps() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Please Turn ON your GPS Connection")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();

    }

    // creating method to create shop

    private void CreateShop() {
        final String shop_name = et_shopname.getText().toString().trim();
        final String shop_lat = et_lat.getText().toString().trim();
        final String shop_longt = et_longt.getText().toString().trim();



        class UpdateEmployee extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(AddShopsActivity.this, "Adding Shop...", "Please Wait...", false, false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if(s.equals("Successfully Register")){
                    Toast.makeText(AddShopsActivity.this, "Shop Added Successfully", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddShopsActivity.this, ViewaddedShopsActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(AddShopsActivity.this, s, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.USER_ID, u_id);
                hashMap.put(Config.SHOP_NAME, shop_name);
                hashMap.put(Config.SHOP_LAT, shop_lat);
                hashMap.put(Config.SHOP_LONGT, shop_longt);

                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.ADDSHOP_URL, hashMap);
                return s;

            }
        }

        UpdateEmployee ue = new UpdateEmployee();
        ue.execute();
    }





    @Override
    public void onClick(View view) {

        if (view==addShops)
        {

            CreateShop();

        }

    }
}
