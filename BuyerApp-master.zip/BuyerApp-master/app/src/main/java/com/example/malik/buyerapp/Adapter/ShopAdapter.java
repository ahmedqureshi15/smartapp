package com.example.malik.buyerapp.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.malik.buyerapp.Modalclasses.Shop;
import com.example.malik.buyerapp.R;

import java.util.List;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.MyViewHolder> {

    public ImageView deleteShop;
    private List<Shop> shopList;
    private ShopAdapter.OnItemClickListener mListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Shop shop = shopList.get(position);
        holder.shopId.setText(shop.getShopId());
        holder.shopName.setText(shop.getShopName());
        holder.shopLat.setText(shop.getShopLat());
        holder.shopLongt.setText(shop.getShopLongt());


    }


    public interface OnItemClickListener {
        void onItemClick(int position);

        void onDeleteClick(int position);
    }

    public ShopAdapter(List<Shop> shopList) {
        this.shopList = shopList;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.shop_list_layout, parent, false);

        return new MyViewHolder(itemView);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView shopId, shopName, shopLat, shopLongt;


        public MyViewHolder(View view) {
            super(view);
            shopId = view.findViewById(R.id.shopId);
            shopName = view.findViewById(R.id.shopName);
            shopLat = view.findViewById(R.id.shopLat);
            shopLongt = view.findViewById(R.id.shopLongt);
            deleteShop = view.findViewById(R.id.deleteImage);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

            deleteShop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onDeleteClick(position);
                        }
                    }
                }
            });


        }
    }

    @Override
    public int getItemCount() {
        return shopList.size();
    }
}

