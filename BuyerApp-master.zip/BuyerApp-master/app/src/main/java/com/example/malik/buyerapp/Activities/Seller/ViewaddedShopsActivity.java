package com.example.malik.buyerapp.Activities.Seller;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.malik.buyerapp.Adapter.ShopAdapter;
import com.example.malik.buyerapp.Constant.Config;
import com.example.malik.buyerapp.Hendler.RequestHandler;
import com.example.malik.buyerapp.Modalclasses.Shop;
import com.example.malik.buyerapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewaddedShopsActivity extends AppCompatActivity implements ShopAdapter.OnItemClickListener {

    private ProgressDialog loading;
    String u_id, shopId;
    String data;
    private List<Shop> shopList = new ArrayList<>();
    private RecyclerView recyclerView;
    private ShopAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewadded_shops);


        recyclerView = findViewById(R.id.recycler_view);
        mAdapter = new ShopAdapter(shopList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

//        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(),
//                DividerItemDecoration.VERTICAL));



        SharedPreferences sharedPreferences = getSharedPreferences(Config.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        u_id = sharedPreferences.getString(Config.ID_SHARED_PREF, "Not Available");


//        calling method
        GetShops();
    }





    private void GetShops() {
        final String user_id = u_id;
        loading = ProgressDialog.show(this, "Please wait...", "Fetching...", false, false);

        class UpdateEmployee extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected void onPostExecute(String s) {
                loading.dismiss();
                super.onPostExecute(s);
                showShops(s);

            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.USER_ID, user_id);
                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.GETSHOPS_URL, hashMap);
                return s;

            }
        }

        UpdateEmployee ue = new UpdateEmployee();
        ue.execute();
    }

//    String status;

    private void showShops(String response) {

        JSONObject obj = null;
        try {

//            Toast.makeText(this, response, Toast.LENGTH_SHORT).show();

            obj = new JSONObject(response);
            data = obj.getString("result");

            JSONArray newArray = new JSONArray(data);


            JSONArray shop_id = new JSONArray();
            JSONArray shop_name = new JSONArray();
            JSONArray shop_lat = new JSONArray();
            JSONArray shop_longt = new JSONArray();

            for (int i = 0; i < newArray.length(); i++) {
                String id = newArray.getJSONObject(i).getString("id");
                String s_name = newArray.getJSONObject(i).getString("shop_name");
                String s_lat = newArray.getJSONObject(i).getString("shop_lat");
                String s_longt = newArray.getJSONObject(i).getString("shop_longt");

                shop_id.put(id);
                shop_name.put(s_name);
                shop_lat.put(s_lat);
                shop_longt.put(s_longt);


                Shop shop = new Shop(
                        newArray.getJSONObject(i).getString("id"),
                        newArray.getJSONObject(i).getString("shop_name"),
                        newArray.getJSONObject(i).getString("shop_lat"),
                        newArray.getJSONObject(i).getString("shop_longt"));
                shopList.add(shop);


            }
            recyclerView.setAdapter(mAdapter);
            mAdapter.setOnItemClickListener(this);

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onItemClick(int position) {

    }

    @Override
    public void onDeleteClick(int position) {
        removeItem(position);
    }


    public void removeItem(int position) {
//        listItems.remove(position);
//        mAdapter.notifyItemRemoved(position);


        Shop clickedItem = shopList.get(position);
        shopId = clickedItem.getShopId();
//        Toast.makeText(this, "Added"+ productName+u_id+listID, Toast.LENGTH_LONG).show();


        class UpdateEmployee extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(ViewaddedShopsActivity.this, "Shop Deleting...", "Please Wait...", false, false);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                if (s.equals("Deleted")) {
                    Toast.makeText(ViewaddedShopsActivity.this, "Shop Deleted Successfully", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(ViewaddedShopsActivity.this, SellerActivity.class);

//                    String listID = listId.getText().toString().trim();
//                    String LName = listName.getText().toString().trim();
////
////
//                    intent.putExtra("LISTID", listID);
//                    intent.putExtra("LISTNAME", LName);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(ViewaddedShopsActivity.this, s, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put(Config.PRODUCT_ID, shopId);
//                hashMap.put(Config.PRODUCT_NAME, productName);
//                hashMap.put(Config.LIST_ID, listID);

                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest(Config.DELETESHOPS_URL, hashMap);
                return s;

            }
        }

        UpdateEmployee ue = new UpdateEmployee();
        ue.execute();
    }


}
