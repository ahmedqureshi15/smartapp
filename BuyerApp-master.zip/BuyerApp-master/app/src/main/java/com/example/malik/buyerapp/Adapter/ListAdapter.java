package com.example.malik.buyerapp.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.malik.buyerapp.Modalclasses.Listclass;
import com.example.malik.buyerapp.R;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.MyViewHolder> {


    private List<Listclass> listName;
    private ImageView deleteList;
    private OnItemClickListener mListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Listclass listclass = listName.get(position);
        holder.l_id.setText(listclass.getListId());
        holder.l_name.setText(listclass.getListName());


    }


    public interface OnItemClickListener {
        void onItemClick(int position);

        void onDeleteClick(int position);
    }

    public ListAdapter(List<Listclass> listName) {
        this.listName = listName;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_layout, parent, false);

        return new MyViewHolder(itemView);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView l_name;
        public TextView l_id;


        public MyViewHolder(View view) {
            super(view);
            l_id = view.findViewById(R.id.listId);
            l_name = view.findViewById(R.id.listName);

            deleteList = view.findViewById(R.id.deleteImage);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

            deleteList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onDeleteClick(position);
                        }
                    }
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return listName.size();
    }
}

